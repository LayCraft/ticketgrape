﻿namespace MovieLab.Directors
{
    partial class DirectorManagerDialog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.btnRemove = new System.Windows.Forms.Button();
            this.lstDirectors = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.MainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.btnEdit);
            this.MainPanel.Controls.Add(this.btnAdd);
            this.MainPanel.Controls.Add(this.lstDirectors);
            this.MainPanel.Controls.Add(this.btnRemove);
            this.MainPanel.Size = new System.Drawing.Size(239, 202);
            // 
            // btnRemove
            // 
            this.btnRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRemove.Location = new System.Drawing.Point(152, 92);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lstDirectors
            // 
            this.lstDirectors.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstDirectors.FormattingEnabled = true;
            this.lstDirectors.Location = new System.Drawing.Point(10, 10);
            this.lstDirectors.Name = "lstDirectors";
            this.lstDirectors.Size = new System.Drawing.Size(136, 147);
            this.lstDirectors.TabIndex = 7;
            this.lstDirectors.SelectedIndexChanged += new System.EventHandler(this.lstDirectors_SelectedIndexChanged);
            this.lstDirectors.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lstDirectors_KeyPress);
            this.lstDirectors.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstDirectors_MouseDoubleClick);
            this.lstDirectors.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.lstDirectors_PreviewKeyDown);
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.Location = new System.Drawing.Point(152, 41);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 15;
            this.btnAdd.Text = "Add...";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit.Location = new System.Drawing.Point(152, 12);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 16;
            this.btnEdit.Text = "Edit...";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // DirectorManagerDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(239, 234);
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(255, 272);
            this.Name = "DirectorManagerDialog";
            this.Text = "Director Manager";
            this.Load += new System.EventHandler(this.DirectorManagerDialog_Load);
            this.MainPanel.ResumeLayout(false);
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button btnRemove;
    private System.Windows.Forms.ListBox lstDirectors;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnEdit;
  }
}

