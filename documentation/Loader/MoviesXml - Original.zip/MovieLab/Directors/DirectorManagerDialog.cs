﻿using System;
using System.Windows.Forms;
using MovieLab.BaseDialogs;
using MovieLab.Data;
using MovieLab.Data.Model;

namespace MovieLab.Directors
{
    public partial class DirectorManagerDialog : OkApplyCancelDialog
    {
        private readonly MovieRepository _movieRepository;
        private readonly BindingSource _bindingSource = new BindingSource();

        public static void ManageDirectors(MovieRepository movieRepository, IWin32Window parentWindow)
        {
            using (DirectorManagerDialog dlg = new DirectorManagerDialog(movieRepository))
            {
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.ShowDialog(parentWindow);
            }
        }

        public DirectorManagerDialog()
        {
            InitializeComponent();
        }

        public DirectorManagerDialog(MovieRepository movieRepository)
            : this()
        {
            _movieRepository = movieRepository;

            _bindingSource.DataSource = _movieRepository;
            _bindingSource.DataMember = "Directors";

            lstDirectors.DataSource = _bindingSource;
            lstDirectors.DisplayMember = "FullName";

            UpdateButtons();
        }

        private void DirectorManagerDialog_Load(object sender, EventArgs e)
        {
            SelectOk();
        }

        void lstDirectors_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdateButtons();
        }

        public Person CurrentDirector
        {
            get
            {
                Person person = lstDirectors.SelectedItem as Person;
                return person;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Person director = new Person();

            using (EditDirectorDialog dlg = new EditDirectorDialog(director))
            {
                dlg.StartPosition = FormStartPosition.CenterParent;
                if (dlg.ShowDialog() != DialogResult.OK) return;

                _movieRepository.Add(director);
                lstDirectors.SelectedItem = director;
                UpdateButtons();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (CurrentDirector == null) return;
            _movieRepository.Remove(CurrentDirector);
            UpdateButtons();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (CurrentDirector == null) return;

            Person directorCopy = new Person(CurrentDirector);

            using (EditDirectorDialog dlg = new EditDirectorDialog(directorCopy))
            {
                dlg.StartPosition = FormStartPosition.CenterParent;
                if (dlg.ShowDialog() != DialogResult.OK) return;

                CurrentDirector.Update(directorCopy);
            }
        }

        private void UpdateButtons()
        {
            btnEdit.Enabled = btnRemove.Enabled = CurrentDirector != null;
        }

        private void lstDirectors_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (CurrentDirector == null) return;
            btnEdit.PerformClick();
        }

        private void lstDirectors_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\r') return;
            e.Handled = true;
            if (CurrentDirector == null) return;
            btnEdit.PerformClick();
        }

        private void lstDirectors_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            e.IsInputKey = e.KeyCode == Keys.Enter && e.Alt == false && e.Control == false && e.Shift == false;
        }

    }
}
