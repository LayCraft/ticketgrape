﻿using System.Windows.Forms;
using MovieLab.BaseDialogs;
using MovieLab.Data.Model;

namespace MovieLab.Directors
{
    public partial class EditDirectorDialog : OkApplyCancelDialog
    {
        public EditDirectorDialog()
        {
            InitializeComponent();
        }

        public EditDirectorDialog(Person owner)
            : this()
        {
            txtFirst.DataBindings.Add("Text", owner, "FirstName", true, DataSourceUpdateMode.OnPropertyChanged);
            txtLast.DataBindings.Add("Text", owner, "LastName", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void EditDirectorDialog_Load(object sender, System.EventArgs e)
        {
            txtFirst.Select();
        }

    }
}
