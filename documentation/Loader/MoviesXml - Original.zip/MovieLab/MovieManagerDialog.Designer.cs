﻿namespace MovieLab
{
    partial class MovieManagerDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.Windows.Forms.MenuStrip menuStrip1;
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MovieManagerDialog));
      this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
      this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.openToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
      this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this._movieListBox = new System.Windows.Forms.ListBox();
      this._descriptionTextBox = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this._ratingTextBox = new System.Windows.Forms.NumericUpDown();
      this._directorComboBox = new System.Windows.Forms.ComboBox();
      this.label3 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
      this.toolStrip2 = new System.Windows.Forms.ToolStrip();
      this._directorsButton = new System.Windows.Forms.ToolStripButton();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.toolStripContainer2 = new System.Windows.Forms.ToolStripContainer();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this._newButton = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this._deleteButton = new System.Windows.Forms.ToolStripButton();
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.toolStripContainer3 = new System.Windows.Forms.ToolStripContainer();
      menuStrip1 = new System.Windows.Forms.MenuStrip();
      menuStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this._ratingTextBox)).BeginInit();
      this.groupBox1.SuspendLayout();
      this.toolStripContainer1.ContentPanel.SuspendLayout();
      this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
      this.toolStripContainer1.SuspendLayout();
      this.toolStrip2.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.toolStripContainer2.ContentPanel.SuspendLayout();
      this.toolStripContainer2.TopToolStripPanel.SuspendLayout();
      this.toolStripContainer2.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.toolStripContainer3.ContentPanel.SuspendLayout();
      this.toolStripContainer3.TopToolStripPanel.SuspendLayout();
      this.toolStripContainer3.SuspendLayout();
      this.SuspendLayout();
      // 
      // menuStrip1
      // 
      menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
      menuStrip1.GripMargin = new System.Windows.Forms.Padding(0, 2, 0, 2);
      menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.helpToolStripMenuItem});
      menuStrip1.Location = new System.Drawing.Point(0, 0);
      menuStrip1.Name = "menuStrip1";
      menuStrip1.Padding = new System.Windows.Forms.Padding(0, 2, 0, 4);
      menuStrip1.Size = new System.Drawing.Size(609, 25);
      menuStrip1.TabIndex = 14;
      menuStrip1.Text = "menuStrip1";
      // 
      // fileToolStripMenuItem1
      // 
      this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem1,
            this.toolStripSeparator,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
      this.fileToolStripMenuItem1.Padding = new System.Windows.Forms.Padding(0, 0, 4, 0);
      this.fileToolStripMenuItem1.Size = new System.Drawing.Size(33, 19);
      this.fileToolStripMenuItem1.Text = "&File";
      // 
      // newToolStripMenuItem
      // 
      this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
      this.newToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.newToolStripMenuItem.Name = "newToolStripMenuItem";
      this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
      this.newToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
      this.newToolStripMenuItem.Text = "&New";
      this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
      // 
      // openToolStripMenuItem1
      // 
      this.openToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem1.Image")));
      this.openToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.openToolStripMenuItem1.Name = "openToolStripMenuItem1";
      this.openToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
      this.openToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
      this.openToolStripMenuItem1.Text = "&Open";
      this.openToolStripMenuItem1.Click += new System.EventHandler(this.openToolStripMenuItem1_Click);
      // 
      // toolStripSeparator
      // 
      this.toolStripSeparator.Name = "toolStripSeparator";
      this.toolStripSeparator.Size = new System.Drawing.Size(143, 6);
      // 
      // saveToolStripMenuItem
      // 
      this.saveToolStripMenuItem.Enabled = false;
      this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
      this.saveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
      this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
      this.saveToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
      this.saveToolStripMenuItem.Text = "&Save";
      this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
      // 
      // saveAsToolStripMenuItem
      // 
      this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
      this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
      this.saveAsToolStripMenuItem.Text = "Save &As";
      this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(143, 6);
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
      this.exitToolStripMenuItem.Text = "E&xit";
      this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
      // 
      // helpToolStripMenuItem
      // 
      this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
      this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
      this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 19);
      this.helpToolStripMenuItem.Text = "&Help";
      // 
      // aboutToolStripMenuItem
      // 
      this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
      this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
      this.aboutToolStripMenuItem.Text = "&About...";
      this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
      // 
      // _movieListBox
      // 
      this._movieListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this._movieListBox.FormattingEnabled = true;
      this._movieListBox.Location = new System.Drawing.Point(0, 0);
      this._movieListBox.Name = "_movieListBox";
      this._movieListBox.Size = new System.Drawing.Size(258, 327);
      this._movieListBox.TabIndex = 0;
      // 
      // _descriptionTextBox
      // 
      this._descriptionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this._descriptionTextBox.Location = new System.Drawing.Point(72, 66);
      this._descriptionTextBox.Multiline = true;
      this._descriptionTextBox.Name = "_descriptionTextBox";
      this._descriptionTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this._descriptionTextBox.Size = new System.Drawing.Size(244, 248);
      this._descriptionTextBox.TabIndex = 4;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(3, 69);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(63, 13);
      this.label1.TabIndex = 5;
      this.label1.Text = "Description:";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(13, 42);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(47, 13);
      this.label2.TabIndex = 6;
      this.label2.Text = "Director:";
      // 
      // _ratingTextBox
      // 
      this._ratingTextBox.Location = new System.Drawing.Point(73, 13);
      this._ratingTextBox.Name = "_ratingTextBox";
      this._ratingTextBox.Size = new System.Drawing.Size(49, 20);
      this._ratingTextBox.TabIndex = 7;
      // 
      // _directorComboBox
      // 
      this._directorComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this._directorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this._directorComboBox.FormattingEnabled = true;
      this._directorComboBox.Location = new System.Drawing.Point(72, 39);
      this._directorComboBox.Name = "_directorComboBox";
      this._directorComboBox.Size = new System.Drawing.Size(244, 21);
      this._directorComboBox.TabIndex = 8;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(13, 15);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(41, 13);
      this.label3.TabIndex = 9;
      this.label3.Text = "Rating:";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.toolStripContainer1);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(335, 385);
      this.groupBox1.TabIndex = 10;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Details";
      // 
      // toolStripContainer1
      // 
      this.toolStripContainer1.BottomToolStripPanelVisible = false;
      // 
      // toolStripContainer1.ContentPanel
      // 
      this.toolStripContainer1.ContentPanel.Controls.Add(this.label3);
      this.toolStripContainer1.ContentPanel.Controls.Add(this.label2);
      this.toolStripContainer1.ContentPanel.Controls.Add(this._ratingTextBox);
      this.toolStripContainer1.ContentPanel.Controls.Add(this._directorComboBox);
      this.toolStripContainer1.ContentPanel.Controls.Add(this._descriptionTextBox);
      this.toolStripContainer1.ContentPanel.Controls.Add(this.label1);
      this.toolStripContainer1.ContentPanel.Padding = new System.Windows.Forms.Padding(10);
      this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(329, 327);
      this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.toolStripContainer1.LeftToolStripPanelVisible = false;
      this.toolStripContainer1.Location = new System.Drawing.Point(3, 16);
      this.toolStripContainer1.Name = "toolStripContainer1";
      this.toolStripContainer1.RightToolStripPanelVisible = false;
      this.toolStripContainer1.Size = new System.Drawing.Size(329, 366);
      this.toolStripContainer1.TabIndex = 10;
      this.toolStripContainer1.Text = "toolStripContainer1";
      // 
      // toolStripContainer1.TopToolStripPanel
      // 
      this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip2);
      // 
      // toolStrip2
      // 
      this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
      this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.toolStrip2.ImageScalingSize = new System.Drawing.Size(32, 32);
      this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._directorsButton});
      this.toolStrip2.Location = new System.Drawing.Point(3, 0);
      this.toolStrip2.Name = "toolStrip2";
      this.toolStrip2.Size = new System.Drawing.Size(102, 39);
      this.toolStrip2.TabIndex = 0;
      // 
      // _directorsButton
      // 
      this._directorsButton.Image = global::MovieLab.Properties.Resources.Director;
      this._directorsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this._directorsButton.Name = "_directorsButton";
      this._directorsButton.Size = new System.Drawing.Size(99, 36);
      this._directorsButton.Text = "Directors...";
      this._directorsButton.Click += new System.EventHandler(this._directorsButton_Click);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.toolStripContainer2);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new System.Drawing.Point(0, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(264, 385);
      this.groupBox2.TabIndex = 11;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Movies";
      // 
      // toolStripContainer2
      // 
      this.toolStripContainer2.BottomToolStripPanelVisible = false;
      // 
      // toolStripContainer2.ContentPanel
      // 
      this.toolStripContainer2.ContentPanel.Controls.Add(this._movieListBox);
      this.toolStripContainer2.ContentPanel.Size = new System.Drawing.Size(258, 327);
      this.toolStripContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.toolStripContainer2.LeftToolStripPanelVisible = false;
      this.toolStripContainer2.Location = new System.Drawing.Point(3, 16);
      this.toolStripContainer2.Name = "toolStripContainer2";
      this.toolStripContainer2.RightToolStripPanelVisible = false;
      this.toolStripContainer2.Size = new System.Drawing.Size(258, 366);
      this.toolStripContainer2.TabIndex = 4;
      this.toolStripContainer2.Text = "toolStripContainer2";
      // 
      // toolStripContainer2.TopToolStripPanel
      // 
      this.toolStripContainer2.TopToolStripPanel.Controls.Add(this.toolStrip1);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
      this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._newButton,
            this.toolStripSeparator1,
            this._deleteButton});
      this.toolStrip1.Location = new System.Drawing.Point(3, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(161, 39);
      this.toolStrip1.TabIndex = 1;
      // 
      // _newButton
      // 
      this._newButton.Image = global::MovieLab.Properties.Resources.Movie;
      this._newButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this._newButton.Name = "_newButton";
      this._newButton.Size = new System.Drawing.Size(76, 36);
      this._newButton.Text = "New...";
      this._newButton.ToolTipText = "New Movie";
      this._newButton.Click += new System.EventHandler(this._newButton_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // _deleteButton
      // 
      this._deleteButton.Image = global::MovieLab.Properties.Resources.Delete;
      this._deleteButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this._deleteButton.Name = "_deleteButton";
      this._deleteButton.Size = new System.Drawing.Size(76, 36);
      this._deleteButton.Text = "Delete";
      this._deleteButton.Click += new System.EventHandler(this._deleteButton_Click);
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(0, 0);
      this.splitContainer1.Name = "splitContainer1";
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
      this.splitContainer1.Panel1MinSize = 200;
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
      this.splitContainer1.Panel2MinSize = 150;
      this.splitContainer1.Size = new System.Drawing.Size(609, 385);
      this.splitContainer1.SplitterDistance = 264;
      this.splitContainer1.SplitterWidth = 10;
      this.splitContainer1.TabIndex = 13;
      // 
      // toolStripContainer3
      // 
      this.toolStripContainer3.BottomToolStripPanelVisible = false;
      // 
      // toolStripContainer3.ContentPanel
      // 
      this.toolStripContainer3.ContentPanel.Controls.Add(this.splitContainer1);
      this.toolStripContainer3.ContentPanel.Size = new System.Drawing.Size(609, 385);
      this.toolStripContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.toolStripContainer3.LeftToolStripPanelVisible = false;
      this.toolStripContainer3.Location = new System.Drawing.Point(10, 10);
      this.toolStripContainer3.Name = "toolStripContainer3";
      this.toolStripContainer3.RightToolStripPanelVisible = false;
      this.toolStripContainer3.Size = new System.Drawing.Size(609, 410);
      this.toolStripContainer3.TabIndex = 15;
      this.toolStripContainer3.Text = "toolStripContainer3";
      // 
      // toolStripContainer3.TopToolStripPanel
      // 
      this.toolStripContainer3.TopToolStripPanel.Controls.Add(menuStrip1);
      // 
      // MovieManagerDialog
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(629, 430);
      this.Controls.Add(this.toolStripContainer3);
      this.MainMenuStrip = menuStrip1;
      this.MinimumSize = new System.Drawing.Size(500, 276);
      this.Name = "MovieManagerDialog";
      this.Padding = new System.Windows.Forms.Padding(10);
      this.Text = "My Movies";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MovieManagerDialog_FormClosing);
      menuStrip1.ResumeLayout(false);
      menuStrip1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this._ratingTextBox)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.toolStripContainer1.ContentPanel.ResumeLayout(false);
      this.toolStripContainer1.ContentPanel.PerformLayout();
      this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
      this.toolStripContainer1.TopToolStripPanel.PerformLayout();
      this.toolStripContainer1.ResumeLayout(false);
      this.toolStripContainer1.PerformLayout();
      this.toolStrip2.ResumeLayout(false);
      this.toolStrip2.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.toolStripContainer2.ContentPanel.ResumeLayout(false);
      this.toolStripContainer2.TopToolStripPanel.ResumeLayout(false);
      this.toolStripContainer2.TopToolStripPanel.PerformLayout();
      this.toolStripContainer2.ResumeLayout(false);
      this.toolStripContainer2.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
      this.splitContainer1.ResumeLayout(false);
      this.toolStripContainer3.ContentPanel.ResumeLayout(false);
      this.toolStripContainer3.TopToolStripPanel.ResumeLayout(false);
      this.toolStripContainer3.TopToolStripPanel.PerformLayout();
      this.toolStripContainer3.ResumeLayout(false);
      this.toolStripContainer3.PerformLayout();
      this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox _movieListBox;
        private System.Windows.Forms.TextBox _descriptionTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown _ratingTextBox;
        private System.Windows.Forms.ComboBox _directorComboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ToolStripContainer toolStripContainer2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton _newButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton _deleteButton;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton _directorsButton;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripContainer toolStripContainer3;
    }
}