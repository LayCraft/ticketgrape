﻿using System.Windows.Forms;
using MovieLab.Data.Model;

namespace MovieLab
{
  public partial class NewMovieDialog : BaseDialogs.OkApplyCancelDialog
  {
      public NewMovieDialog()
      {
          InitializeComponent();
     }

      public NewMovieDialog(Movie movie)
          : this()
      {
          _nameTextBox.DataBindings.Add("Text", movie, "Title", true, DataSourceUpdateMode.OnPropertyChanged);
          _ratingUpDown.DataBindings.Add("Value", movie, "Rating", true, DataSourceUpdateMode.OnPropertyChanged);
          _descriptionTextBox.DataBindings.Add("Text", movie, "Description", true, DataSourceUpdateMode.OnPropertyChanged);

          _nameTextBox.Select();
      }

  }
}
