﻿using System;
using System.Windows.Forms;
using MovieLab.Data;


namespace MovieLab
{
  static class Program
  {
    [STAThread]
    static void Main()
    {
        MovieRepository movieRepository = new MovieRepository();

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MovieManagerDialog(movieRepository));
    }

  }
}
