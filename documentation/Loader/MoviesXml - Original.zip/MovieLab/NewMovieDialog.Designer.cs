﻿namespace MovieLab
{
    partial class NewMovieDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            this._nameTextBox = new System.Windows.Forms.TextBox();
            this._descriptionTextBox = new System.Windows.Forms.TextBox();
            this._ratingUpDown = new System.Windows.Forms.NumericUpDown();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._ratingUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this._ratingUpDown);
            this.MainPanel.Controls.Add(this._descriptionTextBox);
            this.MainPanel.Controls.Add(label3);
            this.MainPanel.Controls.Add(label2);
            this.MainPanel.Controls.Add(label1);
            this.MainPanel.Controls.Add(this._nameTextBox);
            this.MainPanel.Size = new System.Drawing.Size(412, 269);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 15);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(30, 13);
            label1.TabIndex = 1;
            label1.Text = "Title:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(12, 41);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(41, 13);
            label2.TabIndex = 2;
            label2.Text = "Rating:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(12, 71);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(63, 13);
            label3.TabIndex = 3;
            label3.Text = "Description:";
            // 
            // _nameTextBox
            // 
            this._nameTextBox.Location = new System.Drawing.Point(59, 12);
            this._nameTextBox.Name = "_nameTextBox";
            this._nameTextBox.Size = new System.Drawing.Size(155, 20);
            this._nameTextBox.TabIndex = 0;
            // 
            // _descriptionTextBox
            // 
            this._descriptionTextBox.AcceptsReturn = true;
            this._descriptionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._descriptionTextBox.Location = new System.Drawing.Point(15, 87);
            this._descriptionTextBox.Multiline = true;
            this._descriptionTextBox.Name = "_descriptionTextBox";
            this._descriptionTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._descriptionTextBox.Size = new System.Drawing.Size(385, 176);
            this._descriptionTextBox.TabIndex = 4;
            // 
            // _ratingUpDown
            // 
            this._ratingUpDown.Location = new System.Drawing.Point(59, 39);
            this._ratingUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this._ratingUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this._ratingUpDown.Name = "_ratingUpDown";
            this._ratingUpDown.Size = new System.Drawing.Size(54, 20);
            this._ratingUpDown.TabIndex = 6;
            this._ratingUpDown.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // MovieEditorDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BottomButtons = MovieLab.BaseDialogs.OkApplyCancelDialog.DialogButtons.OkCancel;
            this.ClientSize = new System.Drawing.Size(412, 301);
            this.Name = "MovieEditorDialog";
            this.Text = "Movie Editor";
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._ratingUpDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox _nameTextBox;
        private System.Windows.Forms.TextBox _descriptionTextBox;
        private System.Windows.Forms.NumericUpDown _ratingUpDown;

    }
}