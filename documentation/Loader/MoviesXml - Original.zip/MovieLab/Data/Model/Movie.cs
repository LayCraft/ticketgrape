using System;
using System.Xml.Serialization;
using MovieLab.Data.Base;

namespace MovieLab.Data.Model
{
    public class Movie : DomainObject
    {
        private static int _movieCounter;

        public Movie()
        {
            _movieCounter++;
            Title = string.Format("New Movie {0}", _movieCounter);
            Rating = 1;
        }

        public Movie(string title)
        {
            Title = title;
            Rating = 1;
        }

        // Copy constructor
        public Movie(Movie movie)
        {
            Title = movie.Title;
            Rating = movie.Rating;
            Description = movie.Description;
        }

        public Movie Self
        {
            get { return this; }
        }

        private string _title;
        public string Title
        {
            get { return _title; }
            set { SetField(ref _title, value, "Title"); }
        }
        private int _rating;
        public int Rating
        {
            get { return _rating; }
            set { SetField(ref _rating, value, "Rating"); }
        }

        private string _description;
        private Guid? _directorId;

        public string Description
        {
            get { return _description; }
            set { SetField(ref _description, value, "Description"); }
        }

        public Guid? DirectorId
        {
            get { return _directorId; }
            set { _directorId = value; }
        }

        [XmlIgnore]
        public Person Director
        {
            get { return GetById<Person>(DirectorId); }
            set
            {
                Guid? newValue = value != null ? value.Id : (Guid?)null;
                SetField(ref _directorId, newValue, "Director");
            }
        }

        public override string ToString()
        {
            return string.Format("{0}[{1}]", Title, Id);
        }
    }
}