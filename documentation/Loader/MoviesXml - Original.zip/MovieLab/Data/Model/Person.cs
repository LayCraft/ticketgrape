﻿using System;
using System.Xml.Serialization;
using MovieLab.Data.Base;

namespace MovieLab.Data.Model
{
    [Serializable]
    public class Person : DomainObject
    {
        private string _firstName;
        private string _lastName;
        private static int _counter;

        public Person()
        {
            _counter++;
            FirstName = string.Format("FirstName {0}", _counter);
            LastName = string.Format("LastName {0}", _counter);
        }

        public Person(Person person)
        {
            Update(person);
        }

        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public Person Self
        {
            get { return this; }
        }

        public string FirstName
        {
            get { return _firstName; }
            set { SetField(ref _firstName, value, "FirstName", "FullName"); }
        }

        public string LastName
        {
            get { return _lastName; }
            set { SetField(ref _lastName, value, "LastName", "FullName"); }
        }

        [XmlIgnore]
        public string FullName
        {
            get { return _firstName + " " + _lastName; }
        }

        public void Update(Person person)
        {
            FirstName = person.FirstName;
            LastName = person.LastName;
        }

        public override string ToString()
        {
            return string.Format("{0}[{1}]", FullName, Id);
        }

    }
}