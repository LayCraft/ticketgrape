﻿using System.ComponentModel;
using MovieLab.Data.Base;
using MovieLab.Data.Model;

namespace MovieLab.Data
{
    public class MovieRepository : RepositoryBase
    {
        private readonly BindingList<Person> _directors = new BindingList<Person>();
        private readonly BindingList<Movie> _movies = new BindingList<Movie>();
        
        public MovieRepository()
        {
            AddBindingList(typeof(Person), Directors);
            AddBindingList(typeof(Movie), Movies);
        }

        public BindingList<Person> Directors
        {
            get { return _directors; }
        }

        public BindingList<Movie> Movies
        {
            get { return _movies; }
        }
    }
}
